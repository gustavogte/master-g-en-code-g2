1. Crea una aplicación web donde aparezca la imagen de un perro. Debajo de esta imagen debe aparecer un botón que diga “convertir a humano”. Al presionar el boton, la imagen debe transformarse a la imagen de un humano. Al transformar la imagen, el texto del boton debe cambiar y decir “convertir a perro”. Si presionas el boton nuevamente, la imagen vuelve a ser la de un perro y el botón dice nuevamente “convertir a humano”.

2. Crear la siguiente lista de tareas en una página de html:

Prácticar estructuras de datos
Jugar pokemon
Leer 1 hora un libro
Dar de comer a las mascotas

Agregar una botón para cada tarea para marcar como hecho y poner el fondo de la opción de color verde.

3. Agregar un botón que te devuelva en una página de html un número aleatorio entre el 1 y el 100.
