var bands = [
  {
    name: "Oasis",
    description:
      "Oasis fue una banda de Rock inglesa ícono del Britpop formada en Mánchester en 1991.",
    img:
      "https://rtvc-assets-radionica3.s3.amazonaws.com/s3fs-public/styles/image_750x424/public/senalradionica/articulo-noticia/galeriaimagen/oasis_front.jpg?itok=pLfcAjth",
    spotify:
      "<iframe src='https://open.spotify.com/embed/artist/2DaxqgrOhkeH0fpeiQq2f4' width='300' height='380' frameborder='0' allowtransparency='true' allow='encrypted-media'></iframe>",
  },
  {
    name: "Café Tacvba",
    description:
      "Café Tacvba es una banda de rock alternativo, originaria de Ciudad Satélite, Naucalpan, Estado de México.",
    img:
      "https://lh3.googleusercontent.com/WMqYiYn4QLGxZ8Cy9Ky7wcqmj28pqATSrub3-iwQa3O1qLVRYuaE2hi0EFh5eO3NgORgtiFrpWUw0pn-l8-6h8uP",
    spotify:
      "<iframe src='https://open.spotify.com/embed/artist/09xj0S68Y1OU1vHMCZAIvz' width='300' height='380' frameborder='0' allowtransparency='true' allow='encrypted-media'></iframe>",
  },
  {
    name: "Daft Punk",
    description:
      "Daft Punk es un dúo formado por los músicos franceses Guy-Manuel de Homem-Christo y Thomas Bangalter.​​​ Daft Punk alcanzó una gran popularidad en el estilo house a mediados de la década de los años 1990 en Francia y continuó con su éxito los años siguientes, usando el estilo synthpop.​​​",
    img: "https://www.binaural.es/wp-content/uploads/2020/02/daft.jpg",
    spotify:
      "<iframe src='https://open.spotify.com/embed/artist/4tZwfgrHOc3mvqYlEYSvVi' width='300' height='380' frameborder='0' allowtransparency='true' allow='encrypted-media'></iframe>",
  },
];
