Reto Módulo 2

Se te otorgará un JSON con los primeros 151 Pokémons // LISTO
Desplegar cada uno de ellos // LISTO
El sitio debe de ser responsivo para distintos tipos de pantalla (Debes de utilizar Bootstrap) // LISTO
Debes de combinar Bootstrap + tu propio CSS // LISTO
Utiliza componentes animados // LISTO
Si das click a la imagen debes de mostrar la imagen en un tamaño superior en un modal (Puedes usar el componente de Bootstrap) // LISTO
SOLAMENTE PUEDES USAR JS (Solamente puedes utilizar jQuery para las animaciones de Bootstrap) // LISTO
Agregar animaciones a las tarjetas (:hover) // LISTO

Extra

Usa un color que corresponda a el tipo de Pokémon. // LISTO
En el Modal despliega habilidades, tipos y ataques. // PENDIENTE - FALTARON LOS ATAQUES - LISTO
Un buscador de Pokémon // PENDIENTE
