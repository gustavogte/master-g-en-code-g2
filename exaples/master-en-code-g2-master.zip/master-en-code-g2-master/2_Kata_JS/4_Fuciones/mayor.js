//c) Crea una función que se llame mayorDeEdad,
//reciba una edad como parametro y regrese si el
//usuario es "Mayor de edad" o es "Menor de edad"

function mayorDeEdad(edad) {
  if (edad >= 18) {
    console.log("Mayor de Edad");
  } else {
    console.log("Menor de edad");
  }
}
mayorDeEdad(30);
