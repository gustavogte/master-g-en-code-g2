// b) Crea una función llamada subs que reste dos parametros "a" y "b"
// y regrese su resultado.Recuerda que para devolver el valor de
// una función se utiliza la palabra reservada return

function sum(a, b) {
  resultado = a - b;
  return resultado;
}
console.log(sum(4, 5));
