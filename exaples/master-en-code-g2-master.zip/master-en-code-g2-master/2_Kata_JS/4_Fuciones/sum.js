// a) Crea una función llamada sum que reciba dos parametros
//"a" y "b" y regrese la suma de ambos números.
//Recuerda que para devolver el valor de una función
//se utiliza la palabra reservada return

function sum(a, b) {
  resultado = a + b;
  return resultado;
}
console.log(sum(4, 5));
