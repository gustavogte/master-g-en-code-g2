// Asi mostramos algo en la consola
//console.log("Hola Mundo");

// No ocurre nada con esto
"Hola Master en Code :D"; // String
5; // Number
3 + 2; // Number
true; // Boolean
false; // Boolean
undefined; // undefined
null; // null
NaN; // NaN

/*
//Ejemplos de Salida - Output
*/

//console.log("Maui" + "Mali");

//Variables
var saludo; // Declarar variable
saludo = "Hola a todos"; // Asignar un valor

//Declarar y asignar una variable
var respuestaALaVidaElUniversoYTodoLoDemas = 42; // Camel case
var respuestaalavidaeluniversoytodolodemas = 1; // Sin Camel case

// Al sumar texto y otro tipo de dato se convierte a texto

/* console.log(saludo + respuestaALaVidaElUniversoYTodoLoDemas);

console.log(respuestaALaVidaElUniversoYTodoLoDemas + 10);

console.log("Ah, Perro");

alert("Sabres");*/

// 1. Se ejecuta el prompt y me pide escribir algo
// prompt("Este es un ejemplo de entrada (input)");
// 2. El prompt devuelve o retorna lo que escribe el usuario
//"Chilaquil"

// 3. En lugar de perder el texto en el espacio tiempo, podemos
// guardar lo que devuelve en una variable
// var entrada = prompt("Este es un ejemplo de entrada (input)");
// var ejemplo;
// Aqui mandamos a salida una entrada
// console.log(entrada);
// console.log(typeof entrada);
// console.log(ejemplo);

/* Operadores Aritmeticos */
// console.log(5 + 3);
// console.log(10 / 3);
// console.log(10 % 3); // 3 -> 1
var numeroDePokemones = 151;
//console.log(++numeroDePokemones);
var sensei = "Malinali";
var comidasAlDia = 1;
console.log(comidasAlDia);
comidasAlDia += 5;
comigasAlDia = comidasAlDia + 5;
console.log(comidasAlDia);
console.log(comidasAlDia);
comidasAlDia /= 3;
console.log(comidasAlDia);

/* 
  Operadores Logicos
    -Algebra de proposiciones
    -Algebra Booleana
        -Tablas de Verdad
*/

// AND (Y)
console.log(true && true);
console.log(1 > 3 && 1 > 5);
console.log(1 > 0 && 1 > -1);

// OR (o)
console.log(true || false);
console.log(5 >= 4 || 3 <= 1);

//Negacion
console.log(!true && true);
console.log(!(5 >= 4) || 3 <= 1);

// Usar parentesis simplifica la lectura del codigo
