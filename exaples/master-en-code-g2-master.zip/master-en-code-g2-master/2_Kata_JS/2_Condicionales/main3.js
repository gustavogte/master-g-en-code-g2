/*
Crea una aplicación web con JavaScript que reciba tres números digitados
 por el usuario, mediante prompts, y muestre en pantalla, 
 mediante un alert, la suma de los tres números.
*/

numero1 = prompt("Porfavor elije un numero");
numero2 = prompt("Porfavor elije otro numero");
numero3 = prompt("Porfavor elije otro numero");

alert(parseInt(numero1) + parseInt(numero2) + parseInt(numero3));
