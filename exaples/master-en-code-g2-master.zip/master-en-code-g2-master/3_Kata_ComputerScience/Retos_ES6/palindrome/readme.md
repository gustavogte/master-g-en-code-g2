Crea una funcion llamada palindrome() que reciba como parametro una oracion,
si la oracion es un palindromo la funcion debera devolver TRUE, en otro caso devolver
FALSE. Crear

1. Crear una funcion llamada Palindromo
   1.1. Pasar todo a minusculas
   1.2. Convertir la cadena en un arreglo
   1.3. Eliminar los espacios en blanco
2. evaluar revisar si la oracion que se recibe es un palindromo
3. loggear en la consola si es o no palindromo
